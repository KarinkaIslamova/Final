import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        ArrayList<User> users = new ArrayList<>();
        ArrayList<Product> products = new ArrayList<>();
        int id=0;

        User admin= new User();
        admin.setSurname("Admin");
        admin.setName("Admin");
        admin.setMiddliname("Admin");
        admin.setNumberphone("89999999999");
        admin.setEmail("Admin");
        admin.setLogin("admin");
        admin.setPassword("admin");
        admin.setAdministration("admin");
        users.add(admin);








        while (true) {
            System.out.println("1-Авторизоваться\n2-Зарегистрироваться");
            switch (in.nextLine())
            {
                case "1":
                    System.out.println("Авторизация");
                    System.out.println("Введите логин");
                    String login2 = in.nextLine();
                    System.out.println("Введите пароль");
                    String password2 = in.nextLine();

                    for (User user : users) {
                        back:
                        if (user.getLogin().equals(login2) && user.getPassword().equals(password2)) {

                            if (user.getAdministration().equals("admin")) {
                                while (true) {
                                    System.out.println("1-Добавить товар\n2-Удалить товар\n3-Информация о пользователях\n4-Сменить статус пользователя\n0-Выход");
                                    switch (in.nextInt()) {
                                        case 1:
                                            Product product = new Product();
                                            System.out.println("Введите название товара");
                                            in.nextLine();
                                            product.setNameProduct(in.nextLine());
                                            System.out.println("Введите цену");
                                            product.setPrice(in.nextDouble());
                                            products.add(product);
                                            System.out.println("Товар добавлен");
                                            break;

                                        case 2:
                                            for (Product pr : products) {
                                                System.out.println(pr);
                                            }
                                            System.out.println("Введите номер товара, который будет удален");
                                            int del = in.nextInt();
                                            products.remove(del);
                                            System.out.println("Товар был удален");
                                            for (Product pr : products) {
                                                System.out.println(pr);
                                            }
                                            break;

                                        case 3:
                                            for (User us : users) {
                                                System.out.println(us);
                                            }
                                            break;
                                        case 4:
                                            for (User us : users) {
                                                System.out.println(us);
                                            }
                                            System.out.println("Введите номер пользователя  для изменения статуса");
                                            int i = in.nextInt();
                                            user.changeStatus(i);
                                            break;


                                        case 0:

                                            break back;
                                    }
                                }
                            } else if (user.getAdministration().equals("user")) {
                                System.out.println("Вы авторизованы");
                                while (true) {
                                    System.out.println("1-Посмотреть список товаров\n0-Выход");
                                    switch (in.nextInt()) {
                                        case 1:
                                            for (Product pr : products) {
                                                System.out.println(pr);
                                            }
                                            break;
                                        case 0:
                                            break back;

                                    }
                                }
                            }
                        } else {
                            System.out.println("Неверный логин/пароль");
                        }
                        break;
                    }
                    break;

                case "2":
                    User user = new User();
                    System.out.println("Регистрация");
                    System.out.println("Введите фамилию");
                    while (!user.setSurname(in.nextLine())) ;
                    System.out.println("Введите имя");
                    while (!user.setName(in.nextLine())) ;
                    System.out.println("Введите отчество ");
                    while (!user.setMiddliname(in.nextLine())) ;
                    System.out.println("Введите номер телефона");
                    while (!user.setNumberphone(in.nextLine())) ;
                    System.out.println("Введите емаил");
                    user.setEmail(in.nextLine());
                    System.out.println("Введите логин");
                    user.setLogin(in.nextLine());
                    System.out.println("Введите пароль");
                    user.setPassword(in.nextLine());
                    user.setAdministration("user");
                    user.setId(id++);
                    users.add(user);
                    System.out.println("Вы зарегистрированы");

                    break;
            }
        }
    }



}
